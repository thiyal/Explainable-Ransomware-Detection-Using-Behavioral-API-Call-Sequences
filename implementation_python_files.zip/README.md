# Implementation Python files

Extracted from Chapter 4 (Implementation), Listings 4.1–4.11, of `Explainable_Ransomware_Detection_Project_Expanded.docx`. Source code text is preserved; indentation was reconstructed from the Word paragraph indentation. The original module folder paths are retained. Listing 4.12 contains shell commands, not a Python source file, so it is not included.

## Files

- `src/config.py` — Listing 4.1
- `src/taxonomy.py` — Listing 4.2
- `src/preprocess.py` — Listing 4.3
- `src/features.py` — Listing 4.4
- `src/models_tree.py` — Listing 4.5
- `src/metrics.py` — Listing 4.6
- `src/explainability.py` — Listing 4.7
- `src/model_bilstm.py` — Listing 4.8
- `src/pipeline.py` — Listing 4.9
- `app/server.py` — Listing 4.10
- `scripts/run_experiments.py` — Listing 4.11
