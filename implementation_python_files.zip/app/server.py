"""Analyst triage dashboard: REST endpoint + single-page HTML front end (Flask)."""
import json
import os

import joblib
from flask import Flask, jsonify, render_template_string, request

from src.features import ApiVocab
from src.pipeline import ModelBundle, analyze_trace
from src.preprocess import TraceSchemaError

ARTIFACT_DIR = os.environ.get("ARTIFACT_DIR", "artifacts")
MAX_UPLOAD_BYTES = 32 * 1024 * 1024

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = MAX_UPLOAD_BYTES
_BUNDLES = {}


def get_bundle(kind: str) -> ModelBundle:
    """Lazily load and cache a model bundle from ARTIFACT_DIR."""
    if kind in _BUNDLES:
        return _BUNDLES[kind]
    if kind == "xgb":
        import shap
        model = joblib.load(os.path.join(ARTIFACT_DIR, "xgb.joblib"))
        vec = joblib.load(os.path.join(ARTIFACT_DIR, "tfidf.joblib"))
        bundle = ModelBundle("xgb", model, vectorizer=vec,
                            explainer=shap.TreeExplainer(model))
    elif kind == "bilstm":
        import torch
        from src.model_bilstm import AttentionBiLSTM
        vocab = ApiVocab()
        model = AttentionBiLSTM(len(vocab))
        model.load_state_dict(torch.load(
            os.path.join(ARTIFACT_DIR, "bilstm.pt"), map_location="cpu"))
        bundle = ModelBundle("bilstm", model, vocab=vocab)
    else:
        raise KeyError(kind)
    _BUNDLES[kind] = bundle
    return bundle


@app.post("/api/analyze")
def analyze():
    kind = request.form.get("model", "xgb")
    upload = request.files.get("trace")
    if upload is None:
        return jsonify(error="no file part named 'trace'"), 400
    try:
        doc = json.loads(upload.read().decode("utf-8"))
        report = analyze_trace(doc, get_bundle(kind))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return jsonify(error="file is not valid UTF-8 JSON"), 400
    except TraceSchemaError as exc:
        return jsonify(error=f"schema violation: {exc}"), 422
    except KeyError:
        return jsonify(error=f"unknown model '{kind}'"), 400
    return jsonify(report)


@app.get("/")
def index():
    return render_template_string(PAGE)


PAGE = """<!doctype html><title>Explainable Ransomware Triage</title>
<h2>Explainable Ransomware Detection</h2>
<form id="f"><input type="file" name="trace" accept=".json" required>
<select name="model"><option value="xgb">XGBoost + TreeSHAP</option>
<option value="bilstm">Attention-BiLSTM</option></select>
<button>Analyze</button></form><pre id="out"></pre>
<script>
document.getElementById('f').onsubmit = async e => {
e.preventDefault();
const r = await fetch('/api/analyze', {method: 'POST', body: new FormData(e.target)});
document.getElementById('out').textContent = JSON.stringify(await r.json(), null, 2);
};
</script>"""

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
