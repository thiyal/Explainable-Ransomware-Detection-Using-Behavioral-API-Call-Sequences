"""Baseline and tree-ensemble classifiers with family-grouped stratified CV."""
from typing import Dict, List, Sequence

import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.svm import LinearSVC

from .config import CONFIG
from .features import fit_transform_fold
from .metrics import compute_metrics


def build_model(name: str, seed: int = CONFIG.seed):
    """Factory for the four tabular classifiers evaluated in Table 5.2."""
    if name == "logreg":
        return LogisticRegression(max_iter=2000, class_weight="balanced",
                                random_state=seed)
    if name == "svm":
        return LinearSVC(C=1.0, class_weight="balanced", random_state=seed)
    if name == "rf":
        return RandomForestClassifier(n_estimators=300, max_depth=None,
                                        class_weight="balanced", n_jobs=-1,
                                        random_state=seed)
    if name == "xgb":
        from xgboost import XGBClassifier  # imported lazily: optional dependency
        return XGBClassifier(n_estimators=300, max_depth=6, learning_rate=0.1,
                            subsample=0.8, colsample_bytree=0.8,
                            eval_metric="logloss", tree_method="hist",
                            random_state=seed, n_jobs=-1)
    raise ValueError(f"unknown model: {name}")


def positive_scores(model, x) -> np.ndarray:
    """Return a score in R for the positive class (probability if available)."""
    if hasattr(model, "predict_proba"):
        return model.predict_proba(x)[:, 1]
    return model.decision_function(x)  # LinearSVC: signed margin


def make_splitter(n_splits: int = CONFIG.n_splits, seed: int = CONFIG.seed):
    """Stratified, group-disjoint folds: no family or hash spans train and test."""
    return StratifiedGroupKFold(n_splits=n_splits, shuffle=True, random_state=seed)


def run_cv(sequences: Sequence[Sequence[str]], labels: Sequence[int],
            groups: Sequence[str], model_name: str,
            n_splits: int = CONFIG.n_splits, seed: int = CONFIG.seed) -> List[Dict]:
    """Run grouped CV and return one metrics dict per fold."""
    labels = np.asarray(labels)
    splitter = make_splitter(n_splits, seed)
    results = []
    for fold, (tr, te) in enumerate(splitter.split(np.zeros(len(labels)), labels, groups)):
        train_seqs = [sequences[i] for i in tr]
        test_seqs = [sequences[i] for i in te]
        _, x_tr, x_te = fit_transform_fold(train_seqs, test_seqs)
        model = build_model(model_name, seed)
        model.fit(x_tr, labels[tr])
        threshold = 0.0 if model_name == "svm" else CONFIG.decision_threshold
        scores = positive_scores(model, x_te)
        metrics = compute_metrics(labels[te], scores, threshold)
        metrics.update(fold=fold, n_train=len(tr), n_test=len(te), model=model_name)
        results.append(metrics)
    return results


def summarize(fold_results: List[Dict], keys=("accuracy", "f1", "fpr", "auc")) -> Dict:
    """Mean and standard deviation of each metric across folds."""
    out = {}
    for key in keys:
        vals = np.array([r[key] for r in fold_results], dtype=float)
        out[key] = (float(np.nanmean(vals)), float(np.nanstd(vals)))
    return out
