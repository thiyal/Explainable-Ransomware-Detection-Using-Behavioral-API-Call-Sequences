"""Central, immutable experiment configuration (seeds, windows, hyperparameters)."""
from dataclasses import dataclass


@dataclass(frozen=True)
class Config:
    # Reproducibility
    seed: int = 42
    # Sequence normalization
    max_repeat: int = 2                      # run-length threshold k
    windows: tuple = (200, 500, 1000)        # early-detection prefixes T
    # TF-IDF branch
    ngram_range: tuple = (1, 3)
    max_features: int = 5000
    # Cross-validation
    n_splits: int = 5
    # Attention-BiLSTM branch
    embed_dim: int = 64
    hidden_dim: int = 128
    dropout: float = 0.3
    lr: float = 1e-3
    batch_size: int = 64
    epochs: int = 30
    patience: int = 5
    pad_idx: int = 0
    unk_idx: int = 1
    # Explanation reporting
    top_k_ngrams: int = 10
    top_k_peaks: int = 10
    deletion_steps: tuple = (1, 3, 5, 10)
    decision_threshold: float = 0.5


CONFIG = Config()
