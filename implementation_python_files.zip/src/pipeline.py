"""End-to-end inference: validated trace -> verdict + forensic explanation JSON."""
from dataclasses import dataclass
from typing import Any, Dict, Optional

import numpy as np

from .config import CONFIG
from .explainability import (attention_peaks, evaluate_deletion_faithfulness,
                            explain_tree_prediction, tree_deletion_faithfulness)
from .features import ApiVocab
from .preprocess import normalize_with_indices, subsystem_histogram, validate_trace


@dataclass
class ModelBundle:
    """Everything needed to score one trace with one model family."""
    kind: str                       # "xgb" | "rf" | "bilstm"
    model: Any
    vectorizer: Optional[Any] = None
    vocab: Optional[ApiVocab] = None
    window: int = 1000
    explainer: Optional[Any] = None  # cached shap.TreeExplainer


def analyze_trace(doc: Dict, bundle: ModelBundle, cfg=CONFIG) -> Dict:
    """Produce the Table 3.6 forensic payload for one telemetry document."""
    validate_trace(doc)
    apis, raw_idx = normalize_with_indices(
        doc["api_trace"], max_repeat=cfg.max_repeat, window_len=bundle.window)
    if not apis:
        return {"sample_id": doc["sample_id"], "verdict": None,
                "warning": "empty sequence after filtering: no monitored API calls"}
    report: Dict[str, Any] = {
        "sample_id": doc["sample_id"],
        "process_name": doc["process_name"],
        "window_used": len(apis),
        "subsystem_histogram": subsystem_histogram(apis),
    }
    if bundle.kind in ("xgb", "rf"):
        expl = explain_tree_prediction(bundle.model, bundle.vectorizer, apis,
                                        cfg.top_k_ngrams, bundle.explainer)
        prob = float(bundle.model.predict_proba(expl["_x"])[0, 1])
        report["verdict"] = {"label": "Ransomware" if prob >= cfg.decision_threshold
                            else "Benign", "probability": prob}
        report["shap_explanation"] = {
            "base_value": expl["base_value"],
            "top_features": expl["top_attributions"],
            "top_positive": expl["top_positive"],
            "top_negative": expl["top_negative"],
        }
        report["faithfulness"] = tree_deletion_faithfulness(
            bundle.model, expl, cfg.deletion_steps)
    elif bundle.kind == "bilstm":
        import torch
        ids = torch.from_numpy(bundle.vocab.encode(apis, bundle.window))
        bundle.model.eval()
        with torch.no_grad():
            p, alpha = bundle.model(ids.unsqueeze(0))
        prob, alpha = float(p.item()), alpha[0].numpy()
        report["verdict"] = {"label": "Ransomware" if prob >= cfg.decision_threshold
                            else "Benign", "probability": prob}
        report["attention_explanation"] = {"peaks": attention_peaks(
            alpha, apis, raw_idx, doc["api_trace"], cfg.top_k_peaks)}
        report["faithfulness"] = evaluate_deletion_faithfulness(
            bundle.model, ids, torch.from_numpy(alpha), cfg.deletion_steps)
    else:
        raise ValueError(f"unknown model kind: {bundle.kind}")
    return report
