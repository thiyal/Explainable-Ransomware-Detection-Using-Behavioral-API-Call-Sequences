"""TreeSHAP attribution, temporal-attention peaks, and deletion faithfulness."""
from typing import Dict, List, Optional, Sequence

import numpy as np

try:  # shap is imported lazily so unit tests for other modules run without it
    import shap
except ImportError:  # pragma: no cover
    shap = None


# --------------------------------------------------------------------------
# Tabular branch: exact TreeSHAP over TF-IDF n-grams
# --------------------------------------------------------------------------
def _positive_class_values(shap_values, expected_value):
    """Normalize SHAP output shapes across scikit-learn / XGBoost / shap versions."""
    if isinstance(shap_values, list):                       # [class0, class1]
        vals = np.asarray(shap_values[1])
        base = np.atleast_1d(expected_value)[-1]
    else:
        vals = np.asarray(shap_values)
        if vals.ndim == 3:                                  # (n, features, classes)
            vals = vals[:, :, 1]
            base = np.atleast_1d(expected_value)[-1]
        else:                                               # (n, features)
            base = np.atleast_1d(expected_value)[0]
    return vals, float(base)


def explain_tree_prediction(model, vectorizer, api_sequence: Sequence[str],
                            top_k: int = 10, explainer=None) -> Dict:
    """Exact TreeSHAP attributions for one normalized API sequence."""
    if explainer is None:
        explainer = shap.TreeExplainer(model)
    x_vec = vectorizer.transform([" ".join(api_sequence)])
    feature_names = np.asarray(vectorizer.get_feature_names_out())
    # XGBoost treats absent sparse entries as missing (as it did in training), so
    # sparse input must be preserved; scikit-learn forests require dense input.
    shap_input = x_vec if hasattr(model, "get_booster") else x_vec.toarray()
    raw = explainer.shap_values(shap_input)
    vals, base = _positive_class_values(raw, explainer.expected_value)
    vals = vals[0]
    nonzero = x_vec.nonzero()[1]
    attributions = [
        {"ngram": str(feature_names[i]), "tfidf": float(x_vec[0, i]),
        "shap_value": float(vals[i])}
        for i in nonzero
    ]
    attributions.sort(key=lambda a: abs(a["shap_value"]), reverse=True)
    positive = [a for a in attributions if a["shap_value"] > 0][:top_k]
    negative = [a for a in attributions if a["shap_value"] < 0][:top_k]
    return {
        "base_value": base,
        "margin": base + float(vals.sum()),
        "top_attributions": attributions[:top_k],
        "top_positive": positive,
        "top_negative": negative,
        "_dense_shap": vals,
        "_x": x_vec,
    }


def additivity_gap(model, explanation: Dict) -> float:
    """|f(x) - (phi_0 + sum phi_i)| in the explainer's output (margin) space."""
    x = explanation["_x"]
    if hasattr(model, "get_booster"):                       # XGBoost: log-odds margin
        margin = float(model.predict(x, output_margin=True)[0])
    else:                                                   # RF: probability space
        margin = float(model.predict_proba(x)[0, 1])
    return abs(margin - explanation["margin"])


def tree_deletion_faithfulness(model, explanation: Dict, ks=(1, 3, 5, 10),
                                rng: Optional[np.random.Generator] = None,
                                control: bool = False) -> List[Dict]:
    """Zero the top-k attributed TF-IDF features and record the probability drop.

    With ``control=True`` features are chosen uniformly at random among the
    non-zero n-grams, giving the random-masking baseline of Table 5.4.
    """
    x = explanation["_x"].tocsr().copy()
    nonzero = x.nonzero()[1]
    shap_vals = explanation["_dense_shap"]
    if control:
        rng = rng or np.random.default_rng(0)
        order = rng.permutation(nonzero)
    else:
        order = nonzero[np.argsort(-shap_vals[nonzero])]    # most malicious first
    base_prob = float(model.predict_proba(x)[0, 1])
    curve = [{"k_masked": 0, "predicted_prob": base_prob, "confidence_drop": 0.0}]
    for k in ks:
        xp = x.copy().tolil()
        for idx in order[:k]:
            xp[0, idx] = 0.0
        prob = float(model.predict_proba(xp.tocsr())[0, 1])
        curve.append({"k_masked": k, "predicted_prob": prob,
                        "confidence_drop": base_prob - prob})
    return curve


# --------------------------------------------------------------------------
# Sequential branch: attention peaks and deletion faithfulness
# --------------------------------------------------------------------------
def attention_peaks(alpha: np.ndarray, apis: Sequence[str],
                    raw_indices: Sequence[int], raw_events: Sequence[Dict],
                    top_k: int = 10) -> List[Dict]:
    """Map the top-k attention steps back to hooked events and arguments."""
    n = min(len(apis), len(alpha))
    order = np.argsort(-np.asarray(alpha[:n]))[:top_k]
    peaks = []
    for t in sorted(order.tolist()):
        ev = raw_events[raw_indices[t]]
        peaks.append({
            "step": int(t), "api": apis[t], "alpha": float(alpha[t]),
            "timestamp_ms": float(ev.get("timestamp_ms", 0.0)),
            "arguments": ev.get("arguments", {}),
        })
    return peaks


def evaluate_deletion_faithfulness(model, token_ids, alpha_weights,
                                    k_steps=(1, 3, 5, 10), mask_idx: int = 1,
                                    random_control: bool = False, seed: int = 0):
    """Measure the drop in P(y=1) when top-k attributed tokens are masked."""
    import torch
    model.eval()
    with torch.no_grad():
        orig_prob, _ = model(token_ids.unsqueeze(0))
    orig_score = float(orig_prob.item())
    valid = int((token_ids != model.pad_idx).sum().item())
    if random_control:
        gen = torch.Generator().manual_seed(seed)
        ranked = torch.randperm(valid, generator=gen)
    else:
        ranked = torch.argsort(alpha_weights[:valid], descending=True)
    curve = [{"k_masked": 0, "predicted_prob": orig_score, "confidence_drop": 0.0}]
    for k in k_steps:
        perturbed = token_ids.clone()
        perturbed[ranked[:k]] = mask_idx
        with torch.no_grad():
            new_prob, _ = model(perturbed.unsqueeze(0))
        new_score = float(new_prob.item())
        curve.append({"k_masked": k, "predicted_prob": new_score,
                        "confidence_drop": orig_score - new_score})
    return curve


def mean_curve(curves: List[List[Dict]]) -> List[Dict]:
    """Average per-sample deletion curves (rows of Table 5.4)."""
    ks = [pt["k_masked"] for pt in curves[0]]
    return [{"k_masked": k,
            "predicted_prob": float(np.mean([c[i]["predicted_prob"] for c in curves])),
            "confidence_drop": float(np.mean([c[i]["confidence_drop"] for c in curves]))}
            for i, k in enumerate(ks)]
