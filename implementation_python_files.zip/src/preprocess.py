"""Trace validation, subsystem filtering, API-hammering suppression, truncation."""
import json
from typing import Dict, Iterable, List, Sequence, Tuple

from .taxonomy import MONITORED_APIS, API_TO_SUBSYSTEM

REQUIRED_TOP_LEVEL = ("sample_id", "process_name", "api_trace")
REQUIRED_EVENT_FIELDS = ("api_name", "subsystem", "timestamp_ms")


class TraceSchemaError(ValueError):
    """Raised when an input telemetry document violates the Table 3.5 schema."""


def validate_trace(doc: Dict) -> None:
    """Validate a telemetry document against the input JSON schema."""
    for key in REQUIRED_TOP_LEVEL:
        if key not in doc:
            raise TraceSchemaError(f"missing required field: {key}")
    sid = doc["sample_id"]
    if not (isinstance(sid, str) and len(sid) == 64
            and all(c in "0123456789abcdefABCDEF" for c in sid)):
        raise TraceSchemaError("sample_id must be a 64-character hexadecimal SHA-256")
    events = doc["api_trace"]
    if not isinstance(events, list) or not events:
        raise TraceSchemaError("api_trace must be a non-empty array")
    last_ts = float("-inf")
    for i, ev in enumerate(events):
        for field in REQUIRED_EVENT_FIELDS:
            if field not in ev:
                raise TraceSchemaError(f"api_trace[{i}] missing field: {field}")
        ts = float(ev["timestamp_ms"])
        if ts < last_ts:
            raise TraceSchemaError(f"api_trace[{i}] violates timestamp monotonicity")
        last_ts = ts


def load_trace(path: str) -> Dict:
    """Read a UTF-8 JSON trace from disk and validate it."""
    with open(path, "r", encoding="utf-8") as handle:
        doc = json.load(handle)
    validate_trace(doc)
    return doc


def collapse_runs(apis: Iterable[str], max_repeat: int = 2) -> List[int]:
    """Return indices (into the input) kept after run-length suppression.

    A run of identical consecutive calls is truncated to at most ``max_repeat``
    members; the first ``max_repeat`` occurrences are retained.
    """
    kept, prev, run = [], None, 0
    for idx, api in enumerate(apis):
        if api == prev:
            run += 1
        else:
            prev, run = api, 1
        if run <= max_repeat:
            kept.append(idx)
    return kept


def normalize_with_indices(
    raw_events: Sequence[Dict],
    allowed_vocab=MONITORED_APIS,
    max_repeat: int = 2,
    window_len: int = 1000,
) -> Tuple[List[str], List[int]]:
    """Filter, collapse and truncate; also return indices into ``raw_events``.

    The index list lets the explanation layer map an attention peak or n-gram
    back to the original hooked event (arguments, timestamp, file path).
    """
    filtered_idx = [i for i, ev in enumerate(raw_events)
                    if ev.get("api_name") in allowed_vocab]
    filtered = [raw_events[i]["api_name"] for i in filtered_idx]
    keep = collapse_runs(filtered, max_repeat)
    apis = [filtered[j] for j in keep][:window_len]
    raw_idx = [filtered_idx[j] for j in keep][:window_len]
    return apis, raw_idx


def normalize_api_sequence(
    raw_events: Sequence[Dict],
    allowed_vocab=MONITORED_APIS,
    max_repeat: int = 2,
    window_len: int = 1000,
) -> List[str]:
    """Filter monitored Windows APIs, suppress API hammering, truncate to T."""
    return normalize_with_indices(raw_events, allowed_vocab, max_repeat, window_len)[0]


def subsystem_histogram(apis: Sequence[str]) -> Dict[str, int]:
    """Count calls per subsystem; used for dashboard summaries."""
    hist: Dict[str, int] = {}
    for api in apis:
        name = API_TO_SUBSYSTEM.get(api, "unknown")
        hist[name] = hist.get(name, 0) + 1
    return hist
