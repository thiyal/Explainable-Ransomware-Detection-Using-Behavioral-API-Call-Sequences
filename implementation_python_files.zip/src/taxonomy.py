"""Canonical vocabulary of security-relevant Windows API functions (five subsystems)."""

SUBSYSTEMS = {
    "filesystem": [
        "FindFirstFileW", "FindNextFileW", "CreateFileW", "ReadFile", "WriteFile",
        "SetFilePointer", "MoveFileExW", "DeleteFileW",
    ],
    "crypto": [
        "CryptAcquireContextW", "CryptGenKey", "CryptImportKey", "CryptEncrypt",
        "CryptDestroyKey", "BCryptOpenAlgorithmProvider", "BCryptEncrypt",
    ],
    "process": [
        "CreateProcessW", "CreateProcessInternalW", "ShellExecuteExW",
        "NtCreateProcess", "OpenProcess", "TerminateProcess",
    ],
    "registry": [
        "RegOpenKeyExW", "RegCreateKeyExW", "RegSetValueExW", "RegQueryValueExW",
        "RegDeleteValueW",
    ],
    "network": [
        "GetLogicalDrives", "GetDriveTypeW", "WNetOpenEnumW", "WNetEnumResourceW",
        "InternetOpenW", "HttpSendRequestW",
    ],
}

MONITORED_APIS = frozenset(api for group in SUBSYSTEMS.values() for api in group)

API_TO_SUBSYSTEM = {api: name for name, group in SUBSYSTEMS.items() for api in group}

PAD_TOKEN, UNK_TOKEN = "<PAD>", "<UNK>"
