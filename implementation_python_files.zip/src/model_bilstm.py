"""Attention-BiLSTM classifier (PyTorch) with masked additive attention."""
from typing import Dict, List, Sequence, Tuple

import numpy as np
import torch
import torch.nn as nn
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence
from torch.utils.data import DataLoader, TensorDataset

from .config import CONFIG
from .metrics import compute_metrics


def set_determinism(seed: int = CONFIG.seed) -> None:
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


class AttentionBiLSTM(nn.Module):
    def __init__(self, vocab_size: int, embed_dim: int = 64, hidden_dim: int = 128,
                dropout: float = 0.3, pad_idx: int = 0):
        super().__init__()
        self.pad_idx = pad_idx
        self.embedding = nn.Embedding(vocab_size, embed_dim, padding_idx=pad_idx)
        self.bilstm = nn.LSTM(embed_dim, hidden_dim, batch_first=True,
                                bidirectional=True)
        self.dropout = nn.Dropout(dropout)
        self.attn_proj = nn.Linear(hidden_dim * 2, hidden_dim)       # W_h, b
        self.attn_vector = nn.Linear(hidden_dim, 1, bias=False)      # v
        self.classifier = nn.Linear(hidden_dim * 2, 1)               # w_o, b_o

    def encode(self, token_ids: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """Return (logits [B], alpha [B, T]); padded positions get alpha = 0."""
        mask = token_ids != self.pad_idx
        lengths = mask.sum(dim=1).clamp(min=1).cpu()
        emb = self.dropout(self.embedding(token_ids))
        packed = pack_padded_sequence(emb, lengths, batch_first=True,
                                        enforce_sorted=False)
        out, _ = self.bilstm(packed)
        hidden, _ = pad_packed_sequence(out, batch_first=True,
                                        total_length=token_ids.size(1))
        energy = torch.tanh(self.attn_proj(hidden))
        scores = self.attn_vector(energy).squeeze(-1)
        scores = scores.masked_fill(~mask, -1e9)
        alpha = torch.softmax(scores, dim=-1)
        alpha = alpha * mask.float()                  # exact zeros on padding
        context = torch.bmm(alpha.unsqueeze(1), hidden).squeeze(1)
        logits = self.classifier(self.dropout(context)).squeeze(-1)
        return logits, alpha

    def forward(self, token_ids: torch.Tensor):
        logits, alpha = self.encode(token_ids)
        return torch.sigmoid(logits), alpha


def _loader(ids: np.ndarray, labels: np.ndarray, batch_size: int, shuffle: bool, seed: int):
    ds = TensorDataset(torch.from_numpy(ids), torch.from_numpy(labels.astype(np.float32)))
    gen = torch.Generator().manual_seed(seed)
    return DataLoader(ds, batch_size=batch_size, shuffle=shuffle, generator=gen)


@torch.no_grad()
def predict_proba(model: AttentionBiLSTM, ids: np.ndarray, batch_size: int = 128,
                device: str = "cpu") -> np.ndarray:
    model.eval()
    probs: List[np.ndarray] = []
    for (batch,) in DataLoader(TensorDataset(torch.from_numpy(ids)), batch_size=batch_size):
        p, _ = model(batch.to(device))
        probs.append(p.cpu().numpy())
    return np.concatenate(probs) if probs else np.zeros(0)


def train_fold(train_ids, train_y, val_ids, val_y, vocab_size: int,
                cfg=CONFIG, device: str = "cpu") -> Tuple[AttentionBiLSTM, List[Dict]]:
    """Train with Adam + BCE-with-logits; early stop on validation ROC-AUC."""
    set_determinism(cfg.seed)
    model = AttentionBiLSTM(vocab_size, cfg.embed_dim, cfg.hidden_dim,
                            cfg.dropout, cfg.pad_idx).to(device)
    pos = float(np.sum(train_y == 1))
    neg = float(np.sum(train_y == 0))
    pos_weight = torch.tensor([neg / max(pos, 1.0)], device=device)
    loss_fn = nn.BCEWithLogitsLoss(pos_weight=pos_weight)
    opt = torch.optim.Adam(model.parameters(), lr=cfg.lr)
    loader = _loader(train_ids, train_y, cfg.batch_size, True, cfg.seed)
    best_auc, best_state, stale, history = -1.0, None, 0, []
    for epoch in range(cfg.epochs):
        model.train()
        total = 0.0
        for xb, yb in loader:
            xb, yb = xb.to(device), yb.to(device)
            opt.zero_grad()
            logits, _ = model.encode(xb)
            loss = loss_fn(logits, yb)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            opt.step()
            total += loss.item() * xb.size(0)
        val_scores = predict_proba(model, val_ids, device=device)
        m = compute_metrics(val_y, val_scores, cfg.decision_threshold)
        history.append({"epoch": epoch, "train_loss": total / len(train_ids),
                        "val_auc": m["auc"], "val_f1": m["f1"]})
        auc = m["auc"] if not np.isnan(m["auc"]) else m["f1"]
        if auc > best_auc + 1e-6:
            best_auc, stale = auc, 0
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        else:
            stale += 1
            if stale >= cfg.patience:
                break
    if best_state is not None:
        model.load_state_dict(best_state)
    return model, history
