"""Classification metrics used in Tables 5.2 and 5.3."""
from typing import Dict

import numpy as np
from sklearn.metrics import (accuracy_score, confusion_matrix, f1_score,
                            precision_score, recall_score, roc_auc_score)


def compute_metrics(y_true, y_score, threshold: float = 0.5) -> Dict[str, float]:
    y_true = np.asarray(y_true).astype(int)
    y_score = np.asarray(y_score, dtype=float)
    y_pred = (y_score >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    fpr = fp / (fp + tn) if (fp + tn) else float("nan")
    auc = (roc_auc_score(y_true, y_score)
            if len(np.unique(y_true)) == 2 else float("nan"))
    return {
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall": recall_score(y_true, y_pred, zero_division=0),
        "f1": f1_score(y_true, y_pred, zero_division=0),
        "fpr": float(fpr),
        "auc": float(auc),
        "tp": int(tp), "fp": int(fp), "tn": int(tn), "fn": int(fn),
    }
