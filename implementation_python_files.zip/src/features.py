"""Fold-safe TF-IDF n-gram vectorization and integer vocabulary encoding."""
from typing import List, Sequence

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer

from .config import CONFIG
from .taxonomy import MONITORED_APIS


def make_vectorizer(ngram_range=CONFIG.ngram_range, max_features=CONFIG.max_features):
    """Sublinear TF-IDF over whitespace-delimited API tokens.

    ``lowercase=False`` preserves canonical API casing; the token pattern keeps
    each API name intact. ``smooth_idf=True`` yields ln((1+N)/(1+df)) + 1, i.e.
    Equation (2); scikit-learn additionally L2-normalizes each row.
    """
    return TfidfVectorizer(
        token_pattern=r"\S+",
        lowercase=False,
        ngram_range=ngram_range,
        max_features=max_features,
        sublinear_tf=True,
        smooth_idf=True,
        dtype=np.float32,
    )


def sequences_to_docs(sequences: Sequence[Sequence[str]]) -> List[str]:
    return [" ".join(seq) for seq in sequences]


def fit_transform_fold(train_seqs, test_seqs, **kwargs):
    """Fit the vectorizer on the training fold only; transform both splits."""
    vec = make_vectorizer(**kwargs)
    x_train = vec.fit_transform(sequences_to_docs(train_seqs))
    x_test = vec.transform(sequences_to_docs(test_seqs))
    return vec, x_train, x_test


class ApiVocab:
    """Integer vocabulary: index 0 = <PAD>, index 1 = <UNK>, then sorted APIs."""

    def __init__(self, apis=MONITORED_APIS, pad_idx=CONFIG.pad_idx, unk_idx=CONFIG.unk_idx):
        self.pad_idx, self.unk_idx = pad_idx, unk_idx
        self.itos = ["<PAD>", "<UNK>"] + sorted(apis)
        self.stoi = {tok: i for i, tok in enumerate(self.itos)}

    def __len__(self) -> int:
        return len(self.itos)

    def encode(self, seq: Sequence[str], max_len: int) -> np.ndarray:
        ids = np.full(max_len, self.pad_idx, dtype=np.int64)
        for pos, tok in enumerate(seq[:max_len]):
            ids[pos] = self.stoi.get(tok, self.unk_idx)
        return ids

    def encode_batch(self, seqs: Sequence[Sequence[str]], max_len: int) -> np.ndarray:
        if not seqs:
            return np.zeros((0, max_len), dtype=np.int64)
        return np.stack([self.encode(s, max_len) for s in seqs])

    def decode(self, ids: Sequence[int]) -> List[str]:
        return [self.itos[i] for i in ids if i != self.pad_idx]
