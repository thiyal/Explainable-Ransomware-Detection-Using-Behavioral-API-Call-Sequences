"""Reproduce Tables 5.2-5.4 from a dataset manifest.

Manifest CSV columns: sample_id, label (0/1), family, trace_path
"""
import argparse
import json

import numpy as np
import pandas as pd

from src.config import CONFIG
from src.models_tree import run_cv, summarize
from src.preprocess import load_trace, normalize_api_sequence


def load_corpus(manifest: str, window: int):
    df = pd.read_csv(manifest)
    seqs = []
    for path in df["trace_path"]:
        doc = load_trace(path)
        seqs.append(normalize_api_sequence(doc["api_trace"], max_repeat=CONFIG.max_repeat,
                                            window_len=window))
    groups = df["family"].where(df["label"] == 1, df["sample_id"])  # benign: per-binary
    return seqs, df["label"].to_numpy(), groups.to_numpy()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--out", default="results.json")
    args = ap.parse_args()
    results = {}
    for window in CONFIG.windows:
        seqs, y, groups = load_corpus(args.manifest, window)
        for name in ("logreg", "svm", "rf", "xgb"):
            folds = run_cv(seqs, y, groups, name)
            results[f"{name}@T{window}"] = summarize(folds)
            print(name, window, results[f"{name}@T{window}"])
    with open(args.out, "w") as handle:
        json.dump(results, handle, indent=2)


if __name__ == "__main__":
    main()
